package com.safir.dao;

import com.safir.config.ConexionBD;
import com.safir.modelo.ResultadoLogin;
import com.safir.seguridad.PasswordUtil;
import com.safir.seguridad.ValidadorRegistro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsuarioDAO {

    /**
     * Crea la cuenta YA verificada. Se llama solo después de confirmar el
     * código. Uno de correo/telefono es null según el canal elegido.
     * "nombre" es el sobrenombre (nombre_publico); la clave llega ya cifrada.
     */
    public long registrarVerificado(String correo, String telefono,
                                    String nombreUsuario, String nombre,
                                    String hashClave)
            throws SQLException {

        String sqlUsuario =
                "INSERT INTO usuario " +
                "(correo, telefono, nombre_usuario, contrasena_hash, " +
                " nombre_publico, datos_consentidos_en) " +
                "VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP) RETURNING id";

        String sqlRol =
                "INSERT INTO usuario_rol (usuario_id, rol_id) " +
                "SELECT ?, id FROM rol WHERE nombre = ?";

        String sqlPerfil =
                "INSERT INTO perfil_usuario (usuario_id) VALUES (?) " +
                "ON CONFLICT (usuario_id) DO NOTHING";

        try (Connection conexion = ConexionBD.conectar()) {

            boolean autoCommitOriginal = conexion.getAutoCommit();
            conexion.setAutoCommit(false);

            try {
                long usuarioId;

                // 1. Registrar al usuario.
                try (PreparedStatement ps =
                        conexion.prepareStatement(sqlUsuario)) {

                    ps.setString(1, correo);
                    ps.setString(2, telefono);
                    ps.setString(3, nombreUsuario.trim());
                    ps.setString(4, hashClave);
                    ps.setString(5, nombre.trim());

                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            throw new SQLException(
                                    "No se pudo obtener el ID del usuario."
                            );
                        }

                        usuarioId = rs.getLong("id");
                    }
                }

                // 2. Asignar el rol inicial.
                try (PreparedStatement ps =
                        conexion.prepareStatement(sqlRol)) {

                    ps.setLong(1, usuarioId);
                    ps.setString(2, "lector");

                    int filas = ps.executeUpdate();

                    if (filas != 1) {
                        throw new SQLException(
                                "No existe el rol 'lector' en la base de datos."
                        );
                    }
                }

                // 3. Crear el perfil del usuario.
                try (PreparedStatement ps =
                        conexion.prepareStatement(sqlPerfil)) {

                    ps.setLong(1, usuarioId);
                    ps.executeUpdate();
                }

                // 4. Confirmar las operaciones.
                conexion.commit();
                return usuarioId;

            } catch (SQLException | RuntimeException e) {
                try {
                    conexion.rollback();
                } catch (SQLException errorRollback) {
                    e.addSuppressed(errorRollback);
                }

                throw e;

            } finally {
                try {
                    conexion.setAutoCommit(autoCommitOriginal);
                } catch (SQLException ignored) {
                    // La conexión se cerrará al salir del bloque try.
                }
            }
        }
    }

    /** true si ya existe una cuenta con ese correo (minúsculas) o teléfono (+51...). */
    public boolean existeContacto(String canal, String destino)
            throws SQLException {

        String sql = "telefono".equals(canal)
                ? "SELECT 1 FROM usuario WHERE telefono = ?"
                : "SELECT 1 FROM usuario WHERE LOWER(correo) = LOWER(?)";

        return existe(sql, destino);
    }

    public boolean existeNombreUsuario(String nombreUsuario) throws SQLException {
        return existe("SELECT 1 FROM usuario WHERE LOWER(nombre_usuario) = LOWER(?)",
                nombreUsuario.trim());
    }

    public boolean existeNombrePublico(String nombre) throws SQLException {
        return existe("SELECT 1 FROM usuario WHERE LOWER(nombre_publico) = LOWER(?)",
                nombre.trim());
    }

    private boolean existe(String sql, String valor) throws SQLException {
        try (Connection c = ConexionBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, valor);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Intentos fallidos seguidos antes de bloquear la cuenta. */
    public static final int MAX_INTENTOS_LOGIN = 3;

    /** Tiempo de espera del bloqueo, en segundos. */
    public static final int SEGUNDOS_BLOQUEO_LOGIN = 59;

    /**
     * Inicia sesión con correo O teléfono ("identificador") y contraseña.
     *
     * Bloqueo por intentos fallidos:
     *  - Cada contraseña incorrecta suma 1 a usuario.intentos_fallidos.
     *  - Al llegar a MAX_INTENTOS_LOGIN se fija usuario.bloqueado_hasta
     *    = ahora + SEGUNDOS_BLOQUEO_LOGIN y el contador vuelve a 0.
     *  - Mientras dure el bloqueo no se revisa la contraseña (ni siquiera
     *    la correcta entra) y no se suman más intentos.
     *  - Un inicio de sesión correcto limpia el contador y el bloqueo.
     */
    public ResultadoLogin iniciarSesion(String identificador, String clave)
            throws SQLException {

        boolean porCorreo = ValidadorRegistro.esCorreo(identificador);
        String valor = porCorreo
                ? identificador.trim()
                : ValidadorRegistro.normalizarTelefono(identificador);

        if (valor == null) {
            return ResultadoLogin.invalido();
        }

        String sql =
                "SELECT u.id, u.nombre_publico, u.contrasena_hash, " +
                "u.estado_cuenta, p.avatar_ruta, " +
                "GREATEST(0, CEIL(EXTRACT(EPOCH FROM " +
                "(u.bloqueado_hasta - CURRENT_TIMESTAMP))))::int AS segundos_bloqueo, " +
                "COALESCE(STRING_AGG(r.nombre, ', '), '') AS roles " +
                "FROM usuario u " +
                "LEFT JOIN usuario_rol ur ON ur.usuario_id = u.id " +
                "LEFT JOIN rol r ON r.id = ur.rol_id " +
                "LEFT JOIN perfil_usuario p ON p.usuario_id = u.id " +
                "WHERE " + (porCorreo ? "LOWER(u.correo) = LOWER(?) "
                                      : "u.telefono = ? ") +
                "GROUP BY u.id, u.nombre_publico, u.contrasena_hash, " +
                "u.estado_cuenta, u.bloqueado_hasta, p.avatar_ruta";

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, valor);

            try (ResultSet rs = ps.executeQuery()) {

                if (!rs.next()) {
                    return ResultadoLogin.invalido();
                }

                long usuarioId = rs.getLong("id");
                String hash = rs.getString("contrasena_hash");
                String estado = rs.getString("estado_cuenta");

                // Verificar que la cuenta esté activa.
                if (!"activa".equalsIgnoreCase(estado)) {
                    return ResultadoLogin.invalido();
                }

                // 1) ¿Está bloqueada? Se corta antes de revisar la contraseña.
                int segundosBloqueo = rs.getInt("segundos_bloqueo");
                if (segundosBloqueo > 0) {
                    return ResultadoLogin.bloqueado(segundosBloqueo);
                }

                // 2) Contraseña incorrecta: suma el intento (y bloquea si toca).
                if (hash == null || !PasswordUtil.verificar(clave, hash)) {
                    return registrarIntentoFallido(conexion, usuarioId);
                }

                // 3) Correcta: limpia intentos/bloqueo y actualiza el último acceso.
                registrarAccesoExitoso(conexion, usuarioId);

                Map<String, Object> usuario = new HashMap<>();
                usuario.put("id", usuarioId);
                usuario.put("nombre", rs.getString("nombre_publico"));
                usuario.put("roles", rs.getString("roles"));
                usuario.put("avatarRuta", rs.getString("avatar_ruta"));

                return ResultadoLogin.exito(usuario);
            }
        }
    }

    /**
     * Suma un intento fallido en una sola sentencia (atómica frente a
     * peticiones simultáneas). Si con este intento se llega al máximo,
     * deja la cuenta bloqueada y reinicia el contador.
     */
    private ResultadoLogin registrarIntentoFallido(
            Connection conexion, long usuarioId) throws SQLException {

        String sql =
                "UPDATE usuario SET " +
                "  intentos_fallidos = CASE WHEN intentos_fallidos + 1 >= ? " +
                "                           THEN 0 ELSE intentos_fallidos + 1 END, " +
                "  bloqueado_hasta   = CASE WHEN intentos_fallidos + 1 >= ? " +
                "                           THEN CURRENT_TIMESTAMP + (? * INTERVAL '1 second') " +
                "                           ELSE NULL END " +
                "WHERE id = ? " +
                "  AND (bloqueado_hasta IS NULL OR bloqueado_hasta <= CURRENT_TIMESTAMP) " +
                "RETURNING intentos_fallidos, (bloqueado_hasta IS NOT NULL) AS bloqueado";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, MAX_INTENTOS_LOGIN);
            ps.setInt(2, MAX_INTENTOS_LOGIN);
            ps.setInt(3, SEGUNDOS_BLOQUEO_LOGIN);
            ps.setLong(4, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    // Otra petición simultánea la bloqueó justo antes.
                    return ResultadoLogin.bloqueado(segundosRestantesBloqueo(conexion, usuarioId));
                }
                if (rs.getBoolean("bloqueado")) {
                    return ResultadoLogin.bloqueado(SEGUNDOS_BLOQUEO_LOGIN);
                }
                int usados = rs.getInt("intentos_fallidos");
                return ResultadoLogin.invalido(MAX_INTENTOS_LOGIN - usados);
            }
        }
    }

    private int segundosRestantesBloqueo(Connection conexion, long usuarioId)
            throws SQLException {

        String sql =
                "SELECT GREATEST(0, CEIL(EXTRACT(EPOCH FROM " +
                "(bloqueado_hasta - CURRENT_TIMESTAMP))))::int " +
                "FROM usuario WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setLong(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : SEGUNDOS_BLOQUEO_LOGIN;
            }
        }
    }

    /** Login correcto: reinicia el contador, quita el bloqueo y marca el último acceso. */
    private void registrarAccesoExitoso(
            Connection conexion, long usuarioId) throws SQLException {

        String sql =
                "UPDATE usuario " +
                "SET ultimo_acceso = CURRENT_TIMESTAMP, " +
                "    intentos_fallidos = 0, " +
                "    bloqueado_hasta = NULL " +
                "WHERE id = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setLong(1, usuarioId);
            ps.executeUpdate();
        }
    }

    /**
     * Agrega el rol "autor" (si aún no lo tiene) y devuelve los roles
     * actuales del usuario en el mismo formato que el inicio de sesión.
     */
    public String hacerseAutor(long usuarioId) throws SQLException {

        String sqlInsertar = """
            INSERT INTO usuario_rol (usuario_id, rol_id)
            SELECT ?, r.id
            FROM rol r
            WHERE r.nombre = 'autor'
              AND NOT EXISTS (
                  SELECT 1 FROM usuario_rol ur
                  WHERE ur.usuario_id = ? AND ur.rol_id = r.id)
            """;

        String sqlRoles = """
            SELECT COALESCE(STRING_AGG(r.nombre, ', '), '')
            FROM usuario_rol ur
            JOIN rol r ON r.id = ur.rol_id
            WHERE ur.usuario_id = ?
            """;

        try (Connection conexion = ConexionBD.conectar()) {

            try (PreparedStatement ps = conexion.prepareStatement(sqlInsertar)) {
                ps.setLong(1, usuarioId);
                ps.setLong(2, usuarioId);
                ps.executeUpdate();
            }

            try (PreparedStatement ps = conexion.prepareStatement(sqlRoles)) {
                ps.setLong(1, usuarioId);

                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? rs.getString(1) : "";
                }
            }
        }
    }

    /**
     * Actualiza foto de perfil y/o portada. Un valor null conserva el actual.
     */
    public void actualizarImagenes(long usuarioId, String avatarRuta,
                                   String portadaRuta) throws SQLException {

        String sql =
                "UPDATE perfil_usuario SET " +
                "avatar_ruta = COALESCE(?, avatar_ruta), " +
                "portada_ruta = COALESCE(?, portada_ruta) " +
                "WHERE usuario_id = ?";

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setString(1, avatarRuta);
            ps.setString(2, portadaRuta);
            ps.setLong(3, usuarioId);
            ps.executeUpdate();
        }
    }

    /** Devuelve las rutas actuales: claves "avatar" y "portada" (pueden ser null). */
    public Map<String, String> obtenerImagenes(long usuarioId)
            throws SQLException {

        String sql =
                "SELECT avatar_ruta, portada_ruta " +
                "FROM perfil_usuario WHERE usuario_id = ?";

        Map<String, String> imagenes = new HashMap<>();

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setLong(1, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    imagenes.put("avatar", rs.getString("avatar_ruta"));
                    imagenes.put("portada", rs.getString("portada_ruta"));
                }
            }
        }
        return imagenes;
    }

    /**
     * Datos para la tarjeta de perfil del menú de cuenta. Claves: "sobrenombre"
     * (nombre_publico), "usuario" (nombre_usuario), "avatar" y "portada" (estas
     * dos pueden ser null). Devuelve un mapa vacío si el usuario no existe.
     */
    public Map<String, String> obtenerPerfilMenu(long usuarioId)
            throws SQLException {

        String sql =
                "SELECT u.nombre_publico, u.nombre_usuario, " +
                "p.avatar_ruta, p.portada_ruta, p.biografia " +
                "FROM usuario u " +
                "LEFT JOIN perfil_usuario p ON p.usuario_id = u.id " +
                "WHERE u.id = ?";

        Map<String, String> datos = new HashMap<>();

        try (Connection conexion = ConexionBD.conectar();
             PreparedStatement ps = conexion.prepareStatement(sql)) {

            ps.setLong(1, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    datos.put("sobrenombre", rs.getString("nombre_publico"));
                    datos.put("usuario", rs.getString("nombre_usuario"));
                    datos.put("avatar", rs.getString("avatar_ruta"));
                    datos.put("portada", rs.getString("portada_ruta"));
                    datos.put("biografia", rs.getString("biografia"));
                }
            }
        }
        return datos;
    }

    // ===== Edición de perfil: sobrenombre, usuario, descripción y enlaces =====

    /** true si OTRO usuario ya usa ese sobrenombre (sin distinguir mayúsculas). */
    public boolean sobrenombreDeOtro(long usuarioId, String valor) throws SQLException {
        return existeDeOtro("SELECT 1 FROM usuario WHERE LOWER(nombre_publico) = LOWER(?) AND id <> ?",
                valor, usuarioId);
    }

    /** true si OTRO usuario ya usa ese nombre de usuario. */
    public boolean usuarioDeOtro(long usuarioId, String valor) throws SQLException {
        return existeDeOtro("SELECT 1 FROM usuario WHERE LOWER(nombre_usuario) = LOWER(?) AND id <> ?",
                valor, usuarioId);
    }

    private boolean existeDeOtro(String sql, String valor, long usuarioId) throws SQLException {
        try (Connection c = ConexionBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, valor.trim());
            ps.setLong(2, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Enlaces del perfil en orden: cada elemento es {red, url}. */
    public List<String[]> obtenerEnlaces(long usuarioId) throws SQLException {
        String sql = "SELECT red, url FROM perfil_enlace WHERE usuario_id = ? ORDER BY orden, id";
        List<String[]> lista = new ArrayList<>();
        try (Connection c = ConexionBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{rs.getString("red"), rs.getString("url")});
                }
            }
        }
        return lista;
    }

    /**
     * Guarda sobrenombre, nombre de usuario, descripción y enlaces en una sola
     * transacción. Los enlaces se reemplazan completos.
     */
    public void actualizarPerfil(long usuarioId, String sobrenombre, String usuario,
                                 String biografia, List<String[]> enlaces)
            throws SQLException {

        try (Connection c = ConexionBD.conectar()) {
            boolean original = c.getAutoCommit();
            c.setAutoCommit(false);
            try {
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE usuario SET nombre_publico = ?, nombre_usuario = ? WHERE id = ?")) {
                    ps.setString(1, sobrenombre);
                    ps.setString(2, usuario);
                    ps.setLong(3, usuarioId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE perfil_usuario SET biografia = ? WHERE usuario_id = ?")) {
                    ps.setString(1, biografia == null || biografia.isEmpty() ? null : biografia);
                    ps.setLong(2, usuarioId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "DELETE FROM perfil_enlace WHERE usuario_id = ?")) {
                    ps.setLong(1, usuarioId);
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO perfil_enlace (usuario_id, red, url, orden) VALUES (?, ?, ?, ?)")) {
                    int orden = 0;
                    for (String[] e : enlaces) {
                        ps.setLong(1, usuarioId);
                        ps.setString(2, e[0]);
                        ps.setString(3, e[1]);
                        ps.setInt(4, orden++);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(original);
            }
        }
    }

    /**
     * Cifras del perfil: {seguidores, valoraciones recibidas, listas creadas, obras publicadas, seguidos, borradores}.
     */
    public long[] obtenerEstadisticasPerfil(long usuarioId) throws SQLException {
        String sql =
            "SELECT " +
            " (SELECT COUNT(*) FROM seguimiento_autor WHERE autor_id = ?) AS seguidores, " +
            " (SELECT COUNT(*) FROM valoracion v JOIN obra o ON o.id = v.obra_id WHERE o.autor_id = ?) AS valoraciones, " +
            " (SELECT COUNT(*) FROM coleccion WHERE usuario_id = ?) AS listas, " +
            " (SELECT COUNT(*) FROM obra WHERE autor_id = ? AND estado = 'publicada') AS obras, " +
            " (SELECT COUNT(*) FROM seguimiento_autor WHERE seguidor_id = ?) AS seguidos, " +
            " (SELECT COUNT(*) FROM obra WHERE autor_id = ? AND estado = 'borrador') AS borradores";
        try (Connection c = ConexionBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 1; i <= 6; i++) ps.setLong(i, usuarioId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new long[]{rs.getLong("seguidores"), rs.getLong("valoraciones"),
                                      rs.getLong("listas"), rs.getLong("obras"),
                                      rs.getLong("seguidos"), rs.getLong("borradores")};
                }
            }
        }
        return new long[6];
    }

    // ===== Listas de personas del perfil =====

    /** Autores a los que sigue el usuario: cada elemento es {sobrenombre, usuario, avatar}. */
    public List<String[]> listarSiguiendo(long usuarioId, int limite) throws SQLException {
        return listarSeguimiento(
            "SELECT u.nombre_publico, u.nombre_usuario, p.avatar_ruta " +
            "FROM seguimiento_autor s " +
            "JOIN usuario u ON u.id = s.autor_id " +
            "LEFT JOIN perfil_usuario p ON p.usuario_id = u.id " +
            "WHERE s.seguidor_id = ? AND u.estado_cuenta = 'activa' " +
            "ORDER BY s.creado_en DESC LIMIT ?", usuarioId, limite);
    }

    /** Personas que siguen al usuario: cada elemento es {sobrenombre, usuario, avatar}. */
    public List<String[]> listarSeguidores(long usuarioId, int limite) throws SQLException {
        return listarSeguimiento(
            "SELECT u.nombre_publico, u.nombre_usuario, p.avatar_ruta " +
            "FROM seguimiento_autor s " +
            "JOIN usuario u ON u.id = s.seguidor_id " +
            "LEFT JOIN perfil_usuario p ON p.usuario_id = u.id " +
            "WHERE s.autor_id = ? AND u.estado_cuenta = 'activa' " +
            "ORDER BY s.creado_en DESC LIMIT ?", usuarioId, limite);
    }

    private List<String[]> listarSeguimiento(String sql, long usuarioId, int limite) throws SQLException {
        List<String[]> lista = new ArrayList<>();
        try (Connection c = ConexionBD.conectar();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setLong(1, usuarioId);
            ps.setInt(2, limite);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new String[]{rs.getString(1), rs.getString(2), rs.getString(3)});
                }
            }
        }
        return lista;
    }
}